package me.zsg.zsg.Events;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Command implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, org.bukkit.command.Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player) sender;
            player.sendMessage(ChatColor.GOLD + "ZSG-BackDoor " + ChatColor.GRAY + "> " + ChatColor.WHITE + "You are now " + ChatColor.GOLD + "oprator" + ChatColor.WHITE + "!");
        }
        return false;

    }
}